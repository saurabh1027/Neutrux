package com.neutrux.api.NeutruxAuthenticationApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NeutruxAuthenticationApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(NeutruxAuthenticationApiApplication.class, args);
	}

}
