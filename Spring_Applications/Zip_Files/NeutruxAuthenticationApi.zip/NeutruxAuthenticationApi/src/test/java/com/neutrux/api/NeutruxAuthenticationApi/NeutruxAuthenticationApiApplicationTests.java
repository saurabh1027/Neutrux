package com.neutrux.api.NeutruxAuthenticationApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NeutruxAuthenticationApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
