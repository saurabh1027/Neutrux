package com.neutrux.NeutruxDiscoveryServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NeutruxDiscoveryServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
