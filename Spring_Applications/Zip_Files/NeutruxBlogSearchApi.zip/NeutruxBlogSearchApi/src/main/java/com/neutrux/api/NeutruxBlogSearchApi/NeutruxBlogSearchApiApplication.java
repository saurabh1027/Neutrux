package com.neutrux.api.NeutruxBlogSearchApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NeutruxBlogSearchApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(NeutruxBlogSearchApiApplication.class, args);
	}

}
