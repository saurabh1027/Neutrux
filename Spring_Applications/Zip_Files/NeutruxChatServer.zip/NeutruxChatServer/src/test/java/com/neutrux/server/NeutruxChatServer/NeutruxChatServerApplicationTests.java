package com.neutrux.server.NeutruxChatServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NeutruxChatServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
