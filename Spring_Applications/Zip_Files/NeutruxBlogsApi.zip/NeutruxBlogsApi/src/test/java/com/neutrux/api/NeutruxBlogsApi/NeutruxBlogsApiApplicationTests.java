package com.neutrux.api.NeutruxBlogsApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NeutruxBlogsApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
