package com.neutrux.api.NeutruxBlogsApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NeutruxBlogsApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(NeutruxBlogsApiApplication.class, args);
	}

}
