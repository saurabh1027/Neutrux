package com.neutrux.NeutruxApiGateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NeutruxApiGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(NeutruxApiGatewayApplication.class, args);
	}

}
