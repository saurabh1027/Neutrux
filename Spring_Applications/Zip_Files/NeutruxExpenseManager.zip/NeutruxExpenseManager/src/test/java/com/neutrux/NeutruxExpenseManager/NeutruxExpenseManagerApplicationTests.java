package com.neutrux.NeutruxExpenseManager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NeutruxExpenseManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
