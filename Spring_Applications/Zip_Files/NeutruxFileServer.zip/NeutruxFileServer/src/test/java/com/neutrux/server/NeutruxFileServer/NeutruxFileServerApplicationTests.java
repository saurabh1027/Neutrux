package com.neutrux.server.NeutruxFileServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NeutruxFileServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
