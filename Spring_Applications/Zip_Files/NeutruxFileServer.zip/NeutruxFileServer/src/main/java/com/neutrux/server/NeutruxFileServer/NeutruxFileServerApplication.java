package com.neutrux.server.NeutruxFileServer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NeutruxFileServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(NeutruxFileServerApplication.class, args);
	}

}
